# Changelog

> :heart: [**Uptrace.dev** - distributed traces, logs, and errors in one place](https://uptrace.dev)

See https://redis.uptrace.dev/changelog/
